import pandas as pd
import os
from tabulate import tabulate
import numpy as np

TOURNAMENT_NAME = 0
TOURNAMENT_DATA = 1
POINTS_PER_WIN = 3
POINTS_PER_DRAW = 1
POINTS_PER_LOSS = 0


def load_data():
    data_dir = './data'
    tournaments = []
    rules = {}
    for file in os.listdir(data_dir):
        if os.path.split(file)[1].split('.')[1] == 'csv':
            tournaments.append([' '.join(os.path.split(file)[1].split('.')[0].split('_')),
                                pd.read_csv(os.path.join(data_dir, file))[['Date', 'HomeTeam',
                                                                           'AwayTeam', 'FTHG', 'FTAG']]])
        if os.path.split(file)[1].split('.')[1] == 'txt':
            with open(os.path.join(data_dir, file), 'r') as f:
                rules[os.path.split(file)[1].split('.')[0]] = f.readline().split(',')
    for tournament in tournaments:
        tournament[1].columns = ['Date', 'HomeTeam', 'AwayTeam', 'HomeTeamGoals', 'AwayTeamGoals']
    return tournaments, rules


def matches_of_a_team(data, team):
    if data.loc[data['AwayTeam'] == team].shape[0] + data.loc[data['HomeTeam'] == team].shape[0] == 0:
        return 'No such team in tournament'
    else:
        return tabulate(data.loc[(data['AwayTeam'] == team) |
                                 (data['HomeTeam'] == team)],
                        headers='keys', showindex=False)


def matches_by_date(data, date):
    if len(date.split('/')) == 3:
        if date.split('/')[0].isdigit() and date.split('/')[1].isdigit() and date.split('/')[2].isdigit()\
                and len(date.split('/')[2]) == 4:
            if 0 < int(date.split('/')[0]) < 10 and len(date.split('/')[0]) == 1:
                date = '0' + date
            if data.loc[data['Date'] == date].shape[0] == 0:
                return 'No games were played on that day'
            else:
                return tabulate(data.loc[data['Date'] == date], headers='keys', showindex=False)
        else:
            return 'Incorrect date format'
    else:
        return 'Incorrect date format'


def create_ranking_table(data, tie_breaking=False):
    teams = data['HomeTeam'].unique().tolist()
    for team in data['AwayTeam'].unique().tolist():
        if team not in teams:
            teams.append(team)
    tournament_results = pd.DataFrame(columns=['Team', 'Games played', 'Wins', 'Losses', 'Draws', 'Goal difference',
                                               'Goals', 'Away goals', 'Points'],
                                      index=range(len(teams)))
    tournament_results = tournament_results.fillna(0)
    tournament_results['Team'] = teams
    for index, row in data.iterrows():
        tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Games played']] += 1
        tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Goals']] += row['HomeTeamGoals']
        tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Goal difference']] += row[
                                                                                                          'HomeTeamGoals'] - \
                                                                                                      row[
                                                                                                          'AwayTeamGoals']
        tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Games played']] += 1
        tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Goals']] += row['AwayTeamGoals']
        tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Away goals']] += row['AwayTeamGoals']
        tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Goal difference']] += row[
                                                                                                          'AwayTeamGoals'] - \
                                                                                                      row[
                                                                                                          'HomeTeamGoals']
        if row['HomeTeamGoals'] > row['AwayTeamGoals']:
            tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Wins']] += 1
            tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Losses']] += 1
            tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Points']] += POINTS_PER_WIN
            tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Points']] += POINTS_PER_LOSS
        elif row['HomeTeamGoals'] < row['AwayTeamGoals']:
            tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Losses']] += 1
            tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Wins']] += 1
            tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Points']] += POINTS_PER_LOSS
            tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Points']] += POINTS_PER_WIN
        else:
            tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Draws']] += 1
            tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Draws']] += 1
            tournament_results.loc[tournament_results['Team'] == row['HomeTeam'], ['Points']] += POINTS_PER_DRAW
            tournament_results.loc[tournament_results['Team'] == row['AwayTeam'], ['Points']] += POINTS_PER_DRAW
    head_to_head_matters = False
    for rule in current_rules:
        if rule.split(' ')[0] == 'Head-to-head':
            head_to_head_matters = True
            break
    if not head_to_head_matters:
        tournament_results.sort_values(by=[x for x in current_rules], inplace=True,
                                       ascending=False)
        tournament_results['Place'] = np.arange(1, 21)
        tournament_results.set_index(keys='Place', inplace=True)
    else:
        tournament_results.sort_values(by=['Points'], inplace=True, ascending=False)
        tournament_results['Place'] = np.arange(1, len(teams) + 1)
        tournament_results.set_index(keys='Place', inplace=True)
        if not tie_breaking:
            tournament_results = break_ties_head_to_head(tournament_results, data, current_rules)
        else:
            tournament_results.sort_values(
                by=[x.split(sep=' ', maxsplit=1)[1][0].capitalize() + x.split(sep=' ', maxsplit=1)[1][1:] for x in
                    current_rules if x.split(' ')[0] == 'Head-to-head'],
                inplace=True, ascending=False)
        tournament_results['Place'] = np.arange(1, len(teams) + 1)
        tournament_results.set_index(keys='Place', inplace=True)

    return tournament_results


def break_ties_head_to_head(table, data, rules):
    for index, row in table.iterrows():
        tied_teams = [row['Team']]
        tied_places = [index]
        for index_1, row_1 in table.iterrows():
            if row_1['Points'] == row['Points'] and row['Team'] != row_1['Team']:
                tied_teams.append(row_1['Team'])
                tied_places.append(index_1)
        if len(tied_teams) > 1:
            sub_ranking = create_ranking_table(
                data.loc[data['AwayTeam'].isin(tied_teams) & data['HomeTeam'].isin(tied_teams)],
                tie_breaking=True)
            table.reset_index(inplace=True)
            sub_ranking.reset_index(inplace=True)
            # table['Place'] = np.arange(1, table.shape[0]+1)
            # sub_ranking['Place'] = np.arange(1, sub_ranking.shape[0] + 1)
            for team in tied_teams:
                place_in_group = sub_ranking.loc[sub_ranking['Team'] == team].iat[0, 0]
                table.loc[table['Team'] == team, ['Place']] = place_in_group + min(tied_places) - 1
            table.sort_values(by='Place', inplace=True)
            table.set_index(keys='Place', inplace=True)
    return table


data_sources, rules_sources = load_data()
print('Welcome to football tournament manager!')
while True:
    print('Choose one of the tournaments:')
    counter = 1
    for tournament in data_sources:
        print(f'{counter}. {tournament[TOURNAMENT_NAME]}')
        counter += 1
    tournament_choice = input('Your choice: ')
    if not (tournament_choice.isdigit()):
        print('Incorrect input! Try one more time')
    elif int(tournament_choice) > len(data_sources):
        print('Incorrect choice! Try one more time')
    else:
        print(f'You chose {data_sources[int(tournament_choice) - 1][0]}\n')
        current_source = data_sources[int(tournament_choice) - 1][1]
        current_rules = rules_sources[data_sources[int(tournament_choice) - 1][0].split(' ')[0]]
        while True:
            print('\nChoose one option:\n1. Search matches of a team\n2. Search matches by date\n3. Show ranking table\n'
                  '4. Return to tournament choice\n')
            option_choice = input('Your choice: ')
            if not (option_choice.isdigit()):
                print('Incorrect input! Try one more time')
            elif int(option_choice) > 4:
                print('Incorrect choice! Try one more time')
            elif int(option_choice) == 4:
                break
            elif int(option_choice) == 1:
                team_choice = input('\nEnter team name: ')
                print(matches_of_a_team(current_source, team_choice))
            elif int(option_choice) == 2:
                date_choice = input('\nEnter date(DD/MM/YYYY): ')
                print(matches_by_date(current_source, date_choice))
            else:
                print(tabulate(create_ranking_table(current_source), headers='keys', showindex=True))
